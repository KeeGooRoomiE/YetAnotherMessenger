<?php

use Illuminate\Http\Request;
use App\Http\Controllers\NumberController;
use App\Http\Controllers\MessageController;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

// Маршрут для получения текущего значения curNum
Route::get('/number', [NumberController::class, 'getCurrentNumber']);

// Маршрут для инкремента числа curNum
Route::post('/number/increment', [NumberController::class, 'incrementNumber']);
// Маршрут для отправки сообщения
Route::post('/messages', [MessageController::class, 'sendMessage']);

// Маршрут для получения сообщений по псевдониму получателя
Route::get('/messages/{pseudonym}', [MessageController::class, 'getMessages']);
