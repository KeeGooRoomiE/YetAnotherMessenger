<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Message;

class MessageController extends Controller
{
    public function sendMessage(Request $request)
    {
        // Валидация данных запроса
        $request->validate([
            'sender_pseudonym' => 'required|string',
            'receiver_pseudonym' => 'required|string',
            'content' => 'required|string|max:500',
            'expiration_time' => 'nullable|integer',
        ]);

        $message = Message::create([
            'sender_pseudonym' => $request->input('sender_pseudonym'),
            'receiver_pseudonym' => $request->input('receiver_pseudonym'),
            'content' => $request->input('content'),
            'expiration_time' => $request->input('expiration_time'),
        ]);

        return response()->json(['message' => 'Message sent successfully!', 'data' => $message], 201);
    }
    public function getMessages($pseudonym, Request $request)
    {
        $page = $request->query('page', 1);
        $pageSize = $request->query('pageSize', 10);
        
        $messages = Message::where('receiver_pseudonym', $pseudonym)
            ->orderBy('created_at', 'desc')
            ->skip(($page - 1) * $pageSize)
            ->take($pageSize)
            ->get();

        return response()->json(['data' => $messages]);
    }
}
